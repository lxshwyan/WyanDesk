(() => {
        const documentRoot = document.documentElement;
        documentRoot.classList.add('js');
        const scenes = ['dawn', 'ocean', 'night', 'cyber', 'forest', 'sunset', 'iris', 'sand'];
        function applyAppearance(preferences) {
          const scene = scenes.includes(preferences?.scene) ? preferences.scene : preferences ? 'ocean' : 'night';
          documentRoot.dataset.deskScene = scene;
          documentRoot.dataset.deskMaterial = preferences?.transparentAppearance === true ? 'transparent' : 'default';
          const view = preferences?.wallpaperView || {};
          const bounded = (number, fallback, max) => typeof number === 'number' && Number.isFinite(number) ? Math.max(0, Math.min(max, number)) : fallback;
          documentRoot.dataset.deskInk = view.tone === 'dark' ? 'dark' : 'light';
          documentRoot.style.setProperty('--wallpaper-position', `${bounded(view.x, 50, 100)}% ${bounded(view.y, 50, 100)}%`);
          documentRoot.style.setProperty('--clear-surface-opacity', String(bounded(view.strength, 10, 30) / 100));
          const wallpaperIds = ['alpine-lake', 'dune-sunset', 'crete-bay', 'coastal-clouds'];
          const wallpaper = preferences?.wallpaper;
          const favorites = Array.isArray(wallpaper?.favoriteIds) ? [...new Set(wallpaper.favoriteIds.filter((id) => wallpaperIds.includes(id)))] : [];
          const pool = favorites.length ? wallpaperIds.filter((id) => favorites.includes(id)) : wallpaperIds;
          const today = new Date();
          const day = Math.floor(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) / 86400000);
          const selected = wallpaper?.daily === true ? pool[((day % pool.length) + pool.length) % pool.length] : wallpaper?.selectedId;
          const image = (typeof preferences?.customBackground === 'string' ? preferences.customBackground : '') || (wallpaperIds.includes(selected) ? `wallpapers/${selected}.jpg` : '');
          if (image) {
            try { documentRoot.style.setProperty('--desk-startup-image', `url(${JSON.stringify(new URL(image, document.baseURI).href)})`); }
            catch { documentRoot.style.removeProperty('--desk-startup-image'); }
          } else documentRoot.style.removeProperty('--desk-startup-image');
        }
        window.WyanDeskStartup = { applyAppearance };
        let preferences;
        try {
          const saved = JSON.parse(window.localStorage.getItem('wyandesk.state.v1') || 'null');
          preferences = saved && typeof saved === 'object'
            ? saved.preferences && typeof saved.preferences === 'object' ? saved.preferences : {}
            : undefined;
        } catch {
          // A failed preference read must not block the desktop or its fallback.
        }
        applyAppearance(preferences);
        window.setTimeout(() => {
          const mountPoint = document.getElementById('root');
          if (mountPoint?.querySelector('.seo-fallback')) documentRoot.classList.add('seo-fallback-timeout');
        }, 5000);
      })();
