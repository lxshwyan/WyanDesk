(() => {
        const documentRoot = document.documentElement;
        documentRoot.classList.add('js');
        window.setTimeout(() => {
          const mountPoint = document.getElementById('root');
          if (mountPoint?.querySelector('.seo-fallback')) documentRoot.classList.add('seo-fallback-timeout');
        }, 5000);
      })();
